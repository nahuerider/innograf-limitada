<?php
  $divisionsection=$_POST["divisionsection"];
  $titulologo=$_POST["titulologo"];
  $sinopsislogo=$_POST["sinopsislogo"];
  $tituloplano=$_POST["tituloplano"];
  $sinopsisplano=$_POST["sinopsisplano"];
  $desarrolloplano1=$_POST["desarrolloplano1"];
  $desarrolloplano2=$_POST["desarrolloplano2"];
  $facebook=$_POST["facebook"];
  $correoinfo=$_POST["correoinfo"];
  $paginaweb=$_POST["paginaweb"];
  $telefono=$_POST["telefono"];
  $query="UPDATE `index2` SET `titulologo`='$titulologo',`sinopsislogo`='$sinopsislogo',`tituloplano`='$tituloplano',`sipnosisplano`='$sinopsisplano',`desarrolloplano1`='$desarrolloplano1',
  `desarrolloplano2`='$desarrolloplano2',`facebook`='$facebook',`correoinfo`='$correoinfo',`paginaweb`='$paginaweb', `telefono`='$telefono' WHERE `id_index2`='$divisionsection' ";
  require "includes/db_connect.php";
  mysqli_query($queryreloca,$query) or die(mysqli_error($queryreloca));
  header("Location:index2.php");

?>