<?php 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="updateindex2.php" method="POST">
        <select name="divisionsection" required id="">
            <option value="1">Tintas y Sonrisas</option>
            <option value="2">Imprenta Innograf</option>
            <option value="3">Kubo cuantico</option>
        </select>
        <input type="text" name="titulologo" required maxlenght="55">
        <input type="text" name="sinopsislogo" required maxlenght="250">
        <input type="text" name="tituloplano" required maxlenght="55">
        <input type="text" name="sinopsisplano" required maxlenght="250">
        <textarea name="desarrolloplano1" maxlenght="700"></textarea>
        <textarea name="desarrolloplano2" maxlenght="650"></textarea>
        <input type="text" name="facebook">
        <input type="text" name="correoinfo">
        <input type="text" name="paginaweb">
        <input type="text" name="telefono">
        <input type="submit" value="Listo">
    </form>
    
</body>
</html>