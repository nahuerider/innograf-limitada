<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="updateindex3.php" method="POST">
        <input type="text" required name="footerfacebook">
        <input type="text" required  name="footerinstagram">
        <input type="text" required  name="footercorreo">
        <input type="text" required  name="tittleantesdelfooter">
        <input type="text" required  name="tituloprincipal">
        <input type="text" required  name="sinopsisprincipal">
        <input type="submit" value="Listo">
</form>    



</body>
</html>