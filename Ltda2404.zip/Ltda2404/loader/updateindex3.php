<?php
$footerfacebook=$_POST["footerfacebook"];
$footerinstagram=$_POST["footerinstagram"];
$footercorreo=$_POST["footercorreo"];
$tittleantesdelfooter=$_POST["tittleantesdelfooter"];
$tituloprincipal=$_POST["tituloprincipal"];
$sinopsisprincipal=$_POST["sinopsisprincipal"];
$query="UPDATE `index3` SET `footerfacebook`='$footerfacebook',`footerinstgram`='$footerinstagram',`footercorreo`='$footercorreo',`tittleantesdelfooter`='$tittleantesdelfooter',`tituloprincipal`='$tituloprincipal',`sinopsisprincipal`='$sinopsisprincipal'
WHERE `id_index3`=1";
require "includes/db_connect.php";
  mysqli_query($queryreloca,$query) or die(mysqli_error($queryreloca));
  header("Location:index3.php");

?>