<?php
    $numerodesection=$_POST["numerosection"];
    $titulosection=$_POST["titulosection"];
    $sinopsissection=$_POST["sinopsissection"];
    $desarrollosection=$_POST["desarrollosection"];
    $query="UPDATE `index1` SET `titulo`='$titulosection', `sinopsis`='$sinopsissection', `desarrollo`='$desarrollosection' WHERE `id_index1`='$numerodesection'";
    require "includes/db_connect.php";
    mysqli_query($queryreloca,$query) or die(mysqli_error($queryreloca));
    header("Location:index1.php");
?>