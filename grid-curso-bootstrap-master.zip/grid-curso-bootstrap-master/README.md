# Grid utilizada en el Curso Completo de Bootstrap 3
### [Curso completo de Bootstrap desde 0](http://www.falconmasters.com/cursos/curso-bootstrap/)

![Curso completo de Bootstrap desde 0](https://raw.githubusercontent.com/falconmasters/grid-curso-bootstrap/master/img/Curso-completo-de-Bootstrap-desde-0.jpg)

Por: [FalconMasters](http://www.falconmasters.com)
